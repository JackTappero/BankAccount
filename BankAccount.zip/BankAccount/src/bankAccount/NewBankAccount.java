package bankAccount;

public class NewBankAccount {
	public static void main(String[] args) {
	BankAccount bankAccount = new BankAccount("Jack", "Tappero", 509413);
	bankAccount.deposit(1200);
	bankAccount.withdrawal(400);
	bankAccount.accountSummary();
	System.out.println();
	
	CheckingAccount checkingAccount = new CheckingAccount("Jack", "Tappero", 509413, 3.1);
	checkingAccount.deposit(200);
	checkingAccount.processWithdrawal(350);
	checkingAccount.displayAccount();
	}

}
